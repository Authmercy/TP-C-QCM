#ifndef TECHUSED_H
#define TECHUSED_H

#include <QMainWindow>

namespace Ui {
class TechUsed1;
}

class TechUsed : public QMainWindow
{

    Q_OBJECT

public:
    explicit TechUsed (QWidget *parent = nullptr);
    ~TechUsed ();


private slots:



    void on_exit_clicked();

private:
    Ui::TechUsed1  *ui;
    int counter_trunc=0;
};


#endif // TECHUSED_H
