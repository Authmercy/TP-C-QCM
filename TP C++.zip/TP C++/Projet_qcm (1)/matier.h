#ifndef MATIER_H
#define MATIER_H

#include <QDialog>

namespace Ui {
class Matier;
}

class Matier : public QDialog
{
    Q_OBJECT

public:
    explicit Matier(QWidget *parent = nullptr);
    ~Matier();


private slots:
void on_ajouter_clicked();


void on_exit_clicked();

private:
Ui::Matier *ui;
int counter_trunc=0;
};
#endif // MATIER_H
