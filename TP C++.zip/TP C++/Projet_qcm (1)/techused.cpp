
#include "techused.h"
#include "ui_techused.h"
#include <fstream>
#include <iostream>
#include <QString>
#include <QMessageBox>
using namespace std;



TechUsed::TechUsed(QMainWindow *parent) :
