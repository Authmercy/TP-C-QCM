#ifndef TECHUSE_H
#define TECHUSE_H

#include <QDialog>

namespace Ui {
class Techuse;
}

class Techuse : public QDialog
{
    Q_OBJECT

public:
    explicit Techuse(QWidget *parent = nullptr);
    ~Techuse();

    void on_exit_clicked();



private:

    int counter_trunc=0;
    Ui::Techuse *ui;
};

#endif // TECHUSE_H
