#include "techuse.h"
#include "ui_techuse.h"
#include <fstream>
#include <iostream>
#include <QString>
#include <QMessageBox>
using namespace std;


Techuse::Techuse(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Techuse)
{
    ui->setupUi(this);
}


Techuse::~Techuse()
{
    delete ui;
}


void Techuse::on_exit_clicked()
{
    string question_rep="techuse.txt";
    ifstream myfile(question_rep);
    string buffer;
    getline(myfile,buffer);



    myfile.close();
}


