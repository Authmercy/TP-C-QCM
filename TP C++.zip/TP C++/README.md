# QcmQt
This is a simple implementation of an MCQ test generator written in QT c++. 
