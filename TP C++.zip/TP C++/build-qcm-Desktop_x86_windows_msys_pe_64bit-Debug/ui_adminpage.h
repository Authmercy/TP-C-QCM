/********************************************************************************
** Form generated from reading UI file 'adminpage.ui'
**
** Created by: Qt User Interface Compiler version 6.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINPAGE_H
#define UI_ADMINPAGE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AdminPage
{
public:
    QLabel *label;
    QWidget *leftWidget;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QPushButton *techButton;
    QLabel *label_9;
    QPushButton *make_test;
    QPushButton *add_etudiant;
    QPushButton *add_matier;
    QPushButton *exit;
    QLabel *label_5;
    QLabel *label_7;
    QLabel *empLabel;
    QLabel *label_6;
    QLabel *label_10;
    QLabel *deptLabel;

    void setupUi(QDialog *AdminPage)
    {
        if (AdminPage->objectName().isEmpty())
            AdminPage->setObjectName("AdminPage");
        AdminPage->resize(854, 596);
        AdminPage->setStyleSheet(QString::fromUtf8("#AdminPage\n"
"{\n"
"	\n"
"	background:#55aaff;\n"
"}"));
        label = new QLabel(AdminPage);
        label->setObjectName("label");
        label->setGeometry(QRect(290, 70, 541, 101));
        QFont font;
        font.setFamilies({QString::fromUtf8("Calibri Light")});
        font.setPointSize(26);
        label->setFont(font);
        leftWidget = new QWidget(AdminPage);
        leftWidget->setObjectName("leftWidget");
        leftWidget->setGeometry(QRect(-10, 0, 260, 600));
        leftWidget->setStyleSheet(QString::fromUtf8("#leftWidget\n"
"{\n"
"	width:260px;\n"
"	background:#00007f;\n"
"}"));
        label_2 = new QLabel(leftWidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(-70, 10, 325, 125));
        label_2->setPixmap(QPixmap(QString::fromUtf8(":/Images/Corporate Management.png")));
        label_2->setScaledContents(true);
        label_3 = new QLabel(leftWidget);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(0, 118, 261, 31));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Segoe UI")});
        font1.setPointSize(13);
        font1.setBold(true);
        label_3->setFont(font1);
        label_4 = new QLabel(leftWidget);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(0, 146, 261, 20));
        QFont font2;
        font2.setPointSize(9);
        label_4->setFont(font2);
        techButton = new QPushButton(leftWidget);
        techButton->setObjectName("techButton");
        techButton->setGeometry(QRect(0, 420, 260, 44));
        QFont font3;
        font3.setPointSize(11);
        techButton->setFont(font3);
        techButton->setStyleSheet(QString::fromUtf8("#techButton\n"
"{\n"
"	text-align:left;\n"
"	padding-left:26px;\n"
"	border:none;	\n"
"	color:white;	\n"
"	background:#1F1F1F;\n"
"}\n"
"#techButton:hover\n"
"{\n"
"	text-align:left;\n"
"	padding-left:26px;	\n"
"	border:none;	\n"
"	color:white;	\n"
"	background:#333333;\n"
"}"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Images/icons8_Hand_50px.png"), QSize(), QIcon::Normal, QIcon::Off);
        techButton->setIcon(icon);
        techButton->setIconSize(QSize(32, 32));
        label_9 = new QLabel(leftWidget);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(40, 560, 131, 21));
        make_test = new QPushButton(leftWidget);
        make_test->setObjectName("make_test");
        make_test->setGeometry(QRect(60, 260, 131, 31));
        QFont font4;
        font4.setPointSize(9);
        font4.setBold(true);
        make_test->setFont(font4);
        add_etudiant = new QPushButton(leftWidget);
        add_etudiant->setObjectName("add_etudiant");
        add_etudiant->setGeometry(QRect(50, 310, 151, 31));
        add_etudiant->setFont(font4);
        add_matier = new QPushButton(leftWidget);
        add_matier->setObjectName("add_matier");
        add_matier->setGeometry(QRect(30, 360, 171, 31));
        add_matier->setFont(font4);
        exit = new QPushButton(leftWidget);
        exit->setObjectName("exit");
        exit->setGeometry(QRect(130, 500, 88, 27));
        QFont font5;
        font5.setBold(true);
        exit->setFont(font5);
        label_5 = new QLabel(AdminPage);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(270, 200, 238, 136));
        label_5->setPixmap(QPixmap(QString::fromUtf8(":/Images/empcardbg.png")));
        label_5->setScaledContents(true);
        label_7 = new QLabel(AdminPage);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(270, 220, 221, 31));
        QFont font6;
        font6.setPointSize(12);
        font6.setBold(true);
        label_7->setFont(font6);
        empLabel = new QLabel(AdminPage);
        empLabel->setObjectName("empLabel");
        empLabel->setGeometry(QRect(310, 260, 191, 61));
        QFont font7;
        font7.setPointSize(28);
        font7.setBold(true);
        empLabel->setFont(font7);
        empLabel->setStyleSheet(QString::fromUtf8("#empLabel\n"
"{\n"
"	color:white;\n"
"	font-weight:bold;\n"
"}"));
        label_6 = new QLabel(AdminPage);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(510, 210, 238, 136));
        label_6->setStyleSheet(QString::fromUtf8("label_6{\n"
"	background:#0000ff;\n"
"	background-color: rgb(0, 85, 255);\n"
"}"));
        label_6->setPixmap(QPixmap(QString::fromUtf8(":/Images/attendancebg.png")));
        label_6->setScaledContents(true);
        label_10 = new QLabel(AdminPage);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(520, 220, 221, 31));
        label_10->setFont(font6);
        deptLabel = new QLabel(AdminPage);
        deptLabel->setObjectName("deptLabel");
        deptLabel->setGeometry(QRect(550, 260, 191, 61));
        deptLabel->setFont(font7);
        deptLabel->setStyleSheet(QString::fromUtf8("color:white;"));

        retranslateUi(AdminPage);

        QMetaObject::connectSlotsByName(AdminPage);
    } // setupUi

    void retranslateUi(QDialog *AdminPage)
    {
        AdminPage->setWindowTitle(QCoreApplication::translate("AdminPage", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("AdminPage", "Bienvenue sur GED examination system", nullptr));
        label_2->setText(QString());
        label_3->setText(QCoreApplication::translate("AdminPage", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">GED EXAM SYSTEM</span></p><p align=\"center\"><br/></p></body></html>", nullptr));
        label_4->setText(QCoreApplication::translate("AdminPage", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-style:italic; color:#ffffff;\">Examen en QCM</span></p></body></html>", nullptr));
        techButton->setText(QCoreApplication::translate("AdminPage", "Technologie utilis\303\251", nullptr));
        label_9->setText(QCoreApplication::translate("AdminPage", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">App Version: 1.0.0</span></p></body></html>", nullptr));
        make_test->setText(QCoreApplication::translate("AdminPage", "concevoir QCM", nullptr));
        add_etudiant->setText(QCoreApplication::translate("AdminPage", "Ajouter etudiants", nullptr));
        add_matier->setText(QCoreApplication::translate("AdminPage", "Ajouter une matiere", nullptr));
        exit->setText(QCoreApplication::translate("AdminPage", "Exit", nullptr));
        label_5->setText(QString());
        label_7->setText(QCoreApplication::translate("AdminPage", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Total no. PROF</span></p></body></html>", nullptr));
        empLabel->setText(QCoreApplication::translate("AdminPage", "<html><head/><body><p><span style=\" color:#ffffff;\">000</span></p></body></html>", nullptr));
        label_6->setText(QString());
        label_10->setText(QCoreApplication::translate("AdminPage", "<html><head/><body><p align=\"center\"><span style=\" color:#ffffff;\">Total n\302\260 matieres</span></p></body></html>", nullptr));
        deptLabel->setText(QCoreApplication::translate("AdminPage", "<html><head/><body><p><span style=\" font-size:16pt; color:#ffffff;\">000</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AdminPage: public Ui_AdminPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINPAGE_H
