/********************************************************************************
** Form generated from reading UI file 'matier.ui'
**
** Created by: Qt User Interface Compiler version 6.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MATIER_H
#define UI_MATIER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Matier
{
public:
    QLabel *label;
    QLineEdit *name_edit;
    QLabel *label_3;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *ajouter;
    QPushButton *exit;

    void setupUi(QDialog *Matier)
    {
        if (Matier->objectName().isEmpty())
            Matier->setObjectName("Matier");
        Matier->resize(400, 300);
        label = new QLabel(Matier);
        label->setObjectName("label");
        label->setGeometry(QRect(90, 20, 211, 20));
        name_edit = new QLineEdit(Matier);
        name_edit->setObjectName("name_edit");
        name_edit->setGeometry(QRect(170, 120, 151, 25));
        label_3 = new QLabel(Matier);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(29, 120, 131, 25));
        layoutWidget = new QWidget(Matier);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(20, 100, 321, 61));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        ajouter = new QPushButton(Matier);
        ajouter->setObjectName("ajouter");
        ajouter->setGeometry(QRect(70, 230, 88, 27));
        QFont font;
        font.setBold(true);
        ajouter->setFont(font);
        exit = new QPushButton(Matier);
        exit->setObjectName("exit");
        exit->setGeometry(QRect(240, 230, 88, 27));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        exit->setFont(font1);

        retranslateUi(Matier);

        QMetaObject::connectSlotsByName(Matier);
    } // setupUi

    void retranslateUi(QDialog *Matier)
    {
        Matier->setWindowTitle(QCoreApplication::translate("Matier", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("Matier", "Ajouter une matiere", nullptr));
        label_3->setText(QCoreApplication::translate("Matier", "Nom de la matiere", nullptr));
        ajouter->setText(QCoreApplication::translate("Matier", "OK", nullptr));
        exit->setText(QCoreApplication::translate("Matier", "EXIT", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Matier: public Ui_Matier {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MATIER_H
