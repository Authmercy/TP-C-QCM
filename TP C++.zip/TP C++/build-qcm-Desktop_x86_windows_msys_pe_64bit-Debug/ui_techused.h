#pragma once
/********************************************************************************
** Form generated from reading UI file ''
**
** Created by: Qt User Interface Compiler version 6.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TechUsed
{
public:
    QWidget *TechUsed_2;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_9;
    QLabel *label_4;
    QLabel *label_10;
    QLabel *label_6;
    QLabel *label_14;
    QPushButton *pushButton;
    QLabel *label_3;
    QMenuBar *menubar;
    QStatusBar *statusbar;
    QToolBar *toolBar;

    void setupUi(QMainWindow *TechUsed)
    {
        if (TechUsed->objectName().isEmpty())
            TechUsed->setObjectName("TechUsed");
        TechUsed->resize(877, 600);
        TechUsed_2 = new QWidget(TechUsed);
        TechUsed_2->setObjectName("TechUsed_2");
        label = new QLabel(TechUsed_2);
        label->setObjectName("label");
        label->setGeometry(QRect(0, 0, 250, 250));
        label->setPixmap(QPixmap(QString::fromUtf8(":/Images/top_left.png")));
        label->setScaledContents(true);
        label_2 = new QLabel(TechUsed_2);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(160, 220, 115, 115));
        label_2->setPixmap(QPixmap(QString::fromUtf8(":/Images/cpp.png")));
        label_9 = new QLabel(TechUsed_2);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(170, 360, 171, 31));
        QFont font;
        font.setPointSize(14);
        label_9->setFont(font);
        label_4 = new QLabel(TechUsed_2);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(480, 220, 115, 115));
        label_4->setPixmap(QPixmap(QString::fromUtf8(":/Images/qt.png")));
        label_10 = new QLabel(TechUsed_2);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(470, 360, 151, 31));
        label_10->setFont(font);
        label_6 = new QLabel(TechUsed_2);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(200, 0, 460, 191));
        label_6->setPixmap(QPixmap(QString::fromUtf8(":/Images/Corporate Management.png")));
        label_6->setScaledContents(true);
        label_14 = new QLabel(TechUsed_2);
        label_14->setObjectName("label_14");
        label_14->setGeometry(QRect(270, 170, 371, 31));
        label_14->setFont(font);
        pushButton = new QPushButton(TechUsed_2);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(300, 450, 180, 36));
        QFont font1;
        font1.setPointSize(11);
        pushButton->setFont(font1);
        pushButton->setStyleSheet(QString::fromUtf8("#pushButton\n"
"{\n"
"	border:none;\n"
"	background:#F33253;\n"
"	color:white;\n"
"	border-radius:16px;\n"
"}\n"
"\n"
"#pushButton:hover\n"
"{\n"
"	border:2px solid #F33253;\n"
"	background:#2D2D2D;\n"
"	color:#F33253;\n"
"	border-radius:16px;\n"
"}"));
        label_3 = new QLabel(TechUsed_2);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(600, 0, 250, 250));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/Images/top_right.png")));
        label_3->setScaledContents(true);
        TechUsed->setCentralWidget(TechUsed_2);
        menubar = new QMenuBar(TechUsed);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 877, 26));
        TechUsed->setMenuBar(menubar);
        statusbar = new QStatusBar(TechUsed);
        statusbar->setObjectName("statusbar");
        TechUsed->setStatusBar(statusbar);
        toolBar = new QToolBar(TechUsed);
        toolBar->setObjectName("toolBar");
        TechUsed->addToolBar(Qt::TopToolBarArea, toolBar);

        retranslateUi(TechUsed);

        QMetaObject::connectSlotsByName(TechUsed);
    } // setupUi

    void retranslateUi(QMainWindow *TechUsed)
    {
        TechUsed->setWindowTitle(QCoreApplication::translate("TechUsed", "MainWindow", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        label_9->setText(QCoreApplication::translate("TechUsed", "<html><head/><body><p align=\"center\"><span style=\" color:#00007f;\">C++ Language</span></p></body></html>", nullptr));
        label_4->setText(QString());
        label_10->setText(QCoreApplication::translate("TechUsed", "<html><head/><body><p align=\"center\"><span style=\" color:#00007f;\">Qt Framework</span></p></body></html>", nullptr));
        label_6->setText(QString());
        label_14->setText(QCoreApplication::translate("TechUsed", "<html><head/><body><p align=\"center\"><span style=\" color:#00007f;\">EXAM MCQ Management System</span></p></body></html>", nullptr));
        pushButton->setText(QCoreApplication::translate("TechUsed", "Back", nullptr));
        label_3->setText(QString());
        toolBar->setWindowTitle(QCoreApplication::translate("TechUsed", "toolBar", nullptr));
    } // retranslateUi

};

namespace Ui {
class TechUsed1: public Ui_TechUsed {};
} // namespace Ui

QT_END_NAMESPACE

