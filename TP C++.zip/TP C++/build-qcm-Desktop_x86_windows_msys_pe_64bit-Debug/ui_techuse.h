/********************************************************************************
** Form generated from reading UI file 'techuse.ui'
**
** Created by: Qt User Interface Compiler version 6.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TECHUSE_H
#define UI_TECHUSE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Techuse
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_9;
    QLabel *label_4;
    QLabel *label_10;
    QLabel *label_6;
    QLabel *label_14;
    QLabel *label_3;

    void setupUi(QDialog *Techuse)
    {
        if (Techuse->objectName().isEmpty())
            Techuse->setObjectName("Techuse");
        Techuse->resize(904, 549);
        label = new QLabel(Techuse);
        label->setObjectName("label");
        label->setGeometry(QRect(0, -10, 250, 250));
        label->setPixmap(QPixmap(QString::fromUtf8(":/Images/top_left.png")));
        label->setScaledContents(true);
        label_2 = new QLabel(Techuse);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(140, 330, 115, 115));
        label_2->setPixmap(QPixmap(QString::fromUtf8(":/Images/cpp.png")));
        label_9 = new QLabel(Techuse);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(110, 460, 151, 31));
        QFont font;
        font.setPointSize(14);
        label_9->setFont(font);
        label_4 = new QLabel(Techuse);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(510, 340, 115, 115));
        label_4->setPixmap(QPixmap(QString::fromUtf8(":/Images/qt.png")));
        label_10 = new QLabel(Techuse);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(480, 470, 151, 31));
        label_10->setFont(font);
        label_6 = new QLabel(Techuse);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(230, 20, 460, 191));
        label_6->setPixmap(QPixmap(QString::fromUtf8(":/Images/Corporate Management.png")));
        label_6->setScaledContents(true);
        label_14 = new QLabel(Techuse);
        label_14->setObjectName("label_14");
        label_14->setGeometry(QRect(320, 180, 341, 31));
        label_14->setFont(font);
        label_3 = new QLabel(Techuse);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(640, 10, 250, 250));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/Images/top_right.png")));
        label_3->setScaledContents(true);

        retranslateUi(Techuse);

        QMetaObject::connectSlotsByName(Techuse);
    } // setupUi

    void retranslateUi(QDialog *Techuse)
    {
        Techuse->setWindowTitle(QCoreApplication::translate("Techuse", "Dialog", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        label_9->setText(QCoreApplication::translate("Techuse", "<html><head/><body><p align=\"center\"><span style=\" color:#00007f;\">C++ Language</span></p></body></html>", nullptr));
        label_4->setText(QString());
        label_10->setText(QCoreApplication::translate("Techuse", "<html><head/><body><p align=\"center\"><span style=\" color:#00007f;\">Qt Framework</span></p></body></html>", nullptr));
        label_6->setText(QString());
        label_14->setText(QCoreApplication::translate("Techuse", "<html><head/><body><p align=\"center\"><span style=\" color:#00007f;\">Exam MCQ Management System</span></p></body></html>", nullptr));
        label_3->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Techuse: public Ui_Techuse {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TECHUSE_H
